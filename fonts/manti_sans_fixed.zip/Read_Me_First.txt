Thank you for using our typeface.
This is limited character demo version.
This "Demo" font is for personal use only, not for commercial use.
if you would like to consider using it for commercial projects. 
please visit our web page 
http://www.studiotypo.com
Thank you.